# WIFI CONTROL

Aplicación Flutter multiplataforma para administrar redes y routers multimarca, según las funciones que cada equipo y proveedor permitan.

## Estado del proyecto

**Versión inicial 0.1.0 — estructura de interfaz y arquitectura.**

Incluye:
- Panel principal con módulos de Conexión, Dispositivos, Wi-Fi, Velocidad, Seguridad y Diagnóstico.
- Perfil de referencia del Huawei EchoLife HG8245W5-6T.
- Perfil de referencia del KAON CG3000.
- Modelos de datos comunes para routers y dispositivos.
- Contrato `RouterAdapter` para integrar modelos de distintos fabricantes.

**Todavía no incluye conexión real ni control de routers.** Las pantallas muestran el estado de desarrollo. La integración debe implementarse y probarse por modelo, método de acceso y permisos del proveedor. No se guardan contraseñas ni se realizan cambios en routers.

## Requisitos

- Flutter SDK compatible con Dart 3.3 o superior.
- Android Studio o VS Code con extensiones Flutter/Dart.
- Para compilar iOS se necesita macOS con Xcode.

## Ejecutar

Desde la carpeta del proyecto:

```bash
flutter pub get
flutter run
```

Para crear las carpetas de plataforma si aún no existen:

```bash
flutter create --platforms=android,ios,web,windows,macos,linux .
```

Después:

```bash
flutter pub get
flutter run
```

## Estructura

```text
lib/
  main.dart
  models/
    network_device.dart
    router_profile.dart
  services/
    router_adapter.dart
    router_registry.dart
  screens/
    home_screen.dart
    router_detail_screen.dart
```

## Routers de referencia

### Huawei EchoLife HG8245W5-6T
- Panel local observado: `192.168.1.1`
- Tipo: GPON / ONT
- Hardware observado: `1A3D.A`
- Software observado: `V5R020C00S330`
- Bandas observadas: 2.4 GHz y 5 GHz
- Los datos son de referencia y pueden variar según proveedor/firmware.

### KAON CG3000
- Primer equipo de prueba del proyecto.
- La compatibilidad debe verificarse con el firmware y los permisos disponibles.

## Seguridad

- No subir contraseñas, tokens, cookies, números de serie ni capturas con datos privados.
- No implementar acciones destructivas (reinicio, restauración, bloqueo o cambio de Wi-Fi) sin confirmación explícita y pruebas por modelo.
- El descubrimiento de red y la lectura de clientes varían por sistema operativo, permisos y router.
