import '../models/router_profile.dart';

/// Catálogo inicial de equipos de referencia.
/// La presencia en este catálogo NO significa que la conexión esté implementada.
class RouterRegistry {
  static const supportedProfiles = <RouterProfile>[
    RouterProfile.huaweiHg8245w5,
    RouterProfile.kaonCg3000,
  ];
}
