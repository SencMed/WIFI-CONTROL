import '../models/network_device.dart';
import '../models/router_profile.dart';

/// Interfaz común para adaptadores específicos de cada fabricante/modelo.
///
/// Las implementaciones deben documentar el método de acceso, autenticación,
/// permisos requeridos y capacidades disponibles. No asumir que todos los
/// routers exponen una API estándar.
abstract class RouterAdapter {
  RouterProfile get profile;

  Future<bool> testConnection();

  Future<List<NetworkDevice>> getConnectedDevices();

  Future<Map<String, String>> getWifiStatus();
}
